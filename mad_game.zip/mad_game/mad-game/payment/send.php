<?php

$TOKEN = "6659464638:AAFOEw0HNn8AtTaz9CuEgRU39Bt46PrVmbQ"; // Your Bot Token

$ID = -1001981802063; // Your User ID

$ChUsername = "hack666m"; // Your Channel User Name

?>